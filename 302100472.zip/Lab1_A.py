'''
C * (9/5) + 32 = F
'''

celsius = float(input('Enter the temperature in Celsius: '))
fahrenheit = celsius * (9/5) + 32
print(f'That is {fahrenheit:.1f} degrees Fahrenheit!')