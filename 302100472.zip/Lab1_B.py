'''
Enter the price of the item: Enter the sales tax percentage: Your total is $107.00

'''

itemprice = float(input('Enter the price of the item: '))
salestax = float(input('Enter the sales tax percentage: '))
taxtopercent = salestax * .01
costofitem = print(f'Your total is ${taxtopercent * itemprice + itemprice:.2f}')