'''
Enter the year for date 1:
 Enter the month for date 1:
 Enter the day for date 1:
  Enter the year for date 2:
  Enter the month for date 2:
  Enter the day for date 2:
   The difference between 1/16/2004 and 5/17/2024 is 7321 days!

'''

year1 = int(input('Enter the year for date 1: '))
month1 = int(input('Enter the month for date 1: '))
day1 = int(input('Enter the day for date 1: '))
year2 = int(input('Enter the year for date 2: '))
month2 = int(input('Enter the month for date 2: '))
day2 = int(input('Enter the day for date 2: '))

years = (year1 - year2) * 360
months = (month1 - month2) * 30
days = (day1 - day2)

difference = years + months + days
out = print(f'The difference between {month1}/{day1}/{year1} and {month2}/{day2}/{year2} is {abs(difference)} days!')
